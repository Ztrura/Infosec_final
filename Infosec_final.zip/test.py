import numpy as np

a=[1,3,5]
a=np.array(a)
print(a)
b=[0,2]
print(a[b])